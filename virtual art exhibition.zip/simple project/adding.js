// Ambient Light
const ambientLight = new THREE.AmbientLight(0x404040, 2); // Soft white light
scene.add(ambientLight);

// Directional Light
const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
directionalLight.position.set(0, 20, 10);
scene.add(directionalLight);

// Spotlight on artwork
const spotlight = new THREE.SpotLight(0xffffff, 1);
spotlight.position.set(0, 15, -40);
spotlight.target = artwork1;
scene.add(spotlight);
