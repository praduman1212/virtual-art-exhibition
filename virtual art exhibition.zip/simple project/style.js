const loader = new THREE.TextureLoader();

const createArtwork = (imagePath, position) => {
  const texture = loader.load(imagePath);
  const planeGeometry = new THREE.PlaneGeometry(10, 10);
  const planeMaterial = new THREE.MeshBasicMaterial({ map: texture });
  const plane = new THREE.Mesh(planeGeometry, planeMaterial);
  plane.position.set(...position);
  return plane;
};

const artwork1 = createArtwork('path/to/art1.jpg', [0, 5, -49.5]);
const artwork2 = createArtwork('path/to/art2.jpg', [20, 5, -49.5]);
// Add more artworks...

gallery.add(artwork1, artwork2);
