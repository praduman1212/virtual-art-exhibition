// OrbitControls setup
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableZoom = true;
controls.enablePan = true;
controls.maxPolarAngle = Math.PI / 2; // Prevent going below ground
